<template>
    <!-- <card class="flex flex-col items-center justify-center">
        <div class="px-3 py-3">
            <h1 class="text-center text-3xl text-80 font-light">Mail Card</h1>
        </div>
    </card> -->
    <card class="flex items-center">
        <div class="px-3 py-3">
            <p class="mb-2 dim text-80 font-bold">Enter an email address to send mail.</p>
            <input type="text" class="w-full form-control form-input form-input-bordered" v-model="email">
            <div class="flex items-center mt-3" v-if=" ! loading">
                <a @click="sendEmail()" class="btn btn-default btn-primary">Send the email</a>
            </div>
            <div class="mt-3" v-if="loading">
                <span class="font-bold dim text-80">Your email is being sent.</span>
            </div>
               <div class="card col-md-12"  v-for="obrafoto in arrayObrafoto" :key="obrafoto.id">
                            <img class="card-img-top" :src="`${obrafoto.imagen}`" alt="Card image cap">
                          
                            <div class="card-body">
                                <h5 class="card-title">{{obrafoto.codigoObra}}</h5>
                                <h3 class="card-text">{{obrafoto.nombreObra}}.</h3>
                                <p class="card-text">{{obrafoto.texto}}.</p>
                                
                                <!-- <a href="#" class="btn btn-danger">Borrar Foto</a> -->
                                 <div class="col-md-3">
                                    <button type="submit" v-on:click.prevent="borrarFoto(obrafoto.obrafotoid)" class="btn btn-danger float-right">Borrar Foto</button>
                                </div>
                            </div>
                        </div>
        </div>
    </card>
</template>

<script>
export default {
    props: [
        'card',

        // The following props are only available on resource detail cards...
        // 'resource',
        // 'resourceId',
        // 'resourceName',
    ],
     data() {
        return {
            loading : false,
            email : null,
            arrayObrafoto: [],
        }
    },
  mounted() {
        console.log(this.card);
        this.listarFotosObras();
    },
    methods : {

           listarFotosObras: function listarFotosObras(pag, buscar, criterio) {
            var me = this;
            console.log('listarfotosObras');
            
           //console.log('listarFotosObras: pAGE:' + pag + '-BUSCAR:' + me.buscar + '-CRITERIO' + me.criterio + '-');
            var url = '/fotosobras?page=' +pag + '&buscar=' + me.buscar + '&criterio=' + me.criterio;
            axios.get(url).then(function (response) {
              //000  me.hayFotos = 0;
              
              var respuesta = response.data;
               //console.log('INICIO--------listarfotos');

               //console.log(respuesta);
               //0000  me.obrasUsuario();
               //console.log('FIN----------listarfotos');
                me.arrayObrafoto = respuesta.obraFoto.data;
                console.log('fotos ', me.arrayObrafoto);

                if (me.arrayObrafoto.length > 0) {
                    me.hayFotos = 1;
                    //console.log('>0');
                } else {
                        //console.log('no >0');
                    };

                me.pagination = respuesta.pagination;
            }).catch(function (error) {
                if (error.response.status === 401) {
                    window.location = "/login";
                }

                //console.log(error);
            });
        },
     
        sendEmail() {
            this.loading = true;
            axios.post('/nova-vendor/'+this.card.component+'/send-mail', {
                email: this.email
            }).then(response => {
                this.loading = false;
                if(response.data.code == 200) {
                    alert('Your email was sent to ' + this.email );
                }else{
                    alert('There was an error sending your email.');
                }
            }).catch(error => {
                this.loading = false;
                alert('There was an error sending your email.');
            });
        }
    },
}
</script>
<style>    
    .modal-content{
        width: 100% !important;
        position: absolute !important;
    }
    .mostrar{
        display: list-item !important;
        opacity: 1 !important;
        position: absolute !important;
        background-color: #3c29297a !important;
    }
    .div-error{
        display: flex;
        justify-content: center;
    }
    .text-error{
        color: red !important;
        font-weight: bold;
    }
    .img-fluid{

        max-width: 50% !important;
    }
    .img {
  width: 10%;
  margin: auto;
  display: block;
  margin-bottom: 10px;
}
    
</style>
