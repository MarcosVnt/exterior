<template>

  <div>
<!-- <a href="/informepdf?obra="+this.resourceId target="_blank">New tab</a>
 -->
 <!-- <router-link
                    :to="{ name: 'informepdf' }"
                    class="dim btn btn-lg btn-default btn-white text-90 no-text-shadow tracking-wide uppercase"
                >
                    {{ __('Generar Informe PDF') }}
                </router-link> -->

    <div class="col-md-6">
                  <button type="submit" v-on:click.prevent="informePdf(resourceId)" 
                  class="dim btn btn-lg btn-default btn-white text-90 no-text-shadow tracking-wide uppercase">Generar Informe PDF</button>
                       </div>  

    <gallery :images="images" :index="index" @close="index = null"></gallery>
    <div
      class="image"
      v-for="(image, imageIndex) in images"
      :key="imageIndex"
      @click="index = imageIndex"
      :style="{ backgroundImage: 'url(' + image + ')', width: '300px', height: '200px' }"
    >
     <button
                                rel="prev"
                                dusk="previous"
                                @click.prevent="seleccionarFoto(image.id)"
                                class="span6 btn btn-link py-3 px-4 text-80 dim"
                                
                              >
                              Seleccionar Foto 
                            

                            </button>
    </div>

        
                                
    </div>
</template>

<script>
  import VueGallery from 'vue-gallery';
  
  export default {
       props: [
        'card',

        // The following props are only available on resource detail cards...
         'resource',
         'resourceId',
         'resourceName',
    ],
    data: function () {
      return {
        
/*          images3: [
          {
            title: '400x400',
            description: '400 x 400 White',
            href: 'https://dummyimage.com/400/ffffff/000000',
          },
          {
            title: '400x400',
            description: '400 x 400 White',
            href: 'https://dummyimage.com/400/ffffff/000000',
          },
          {
            title: '400x400',
            description: '400 x 400 Black',
            href: 'https://dummyimage.com/400/000000/ffffff',
          },
          {
            title: '400x400',
            description: '400 x 400 Black',
            href: 'https://dummyimage.com/400/000000/ffffff',
          },
        ],
 */        
        
        
/*         
        images2: [
          'http://rotuleon.rutasgp.com:8081/storage/obras/images/06252020/20200723080306_image002.jpg',
          'http://rotuleon.rutasgp.com:8081/storage/obras/images/06252020/20200723080255_image001.jpg',
          'http://rotuleon.rutasgp.com:8081/storage/obras/images/06252020/20200723080306_image002.jpg',
          'http://rotuleon.rutasgp.com:8081/storage/obras/images/06252020/20200723080255_image001.jpg',
        ],
 */         
        images: [],
        index: null
      };
    },

    components: {
      'gallery': VueGallery
    },
 mounted() {
        console.log('listarfotosObras mounted', 
        'card',this.card,
         'resource',this.resouce,
         'resourceId',this.resourceId,
         'resourceName',this.resourceName
         );
        this.listarFotosDeUnaObra();
    },
    methods: {
      seleccionarFoto(){
        console.log('seleccionar');
      },

          informePdf(obra) {
            console.log('informe pdf',obra, window.location.hostname);
           window.open('http://'+window.location.hostname+':8081/informepdf?obra='+obra+','+'_blank');
          },

          listarFotosDeUnaObra: function listarFotosDeUnaObra(pag, buscar, criterio) {
            var me = this;
            console.log('listarfotosObras');
            
           //console.log('listarFotosObras: pAGE:' + pag + '-BUSCAR:' + me.buscar + '-CRITERIO' + me.criterio + '-');
            var url = '/fotosunaobra?page=' +pag + '&buscar=' + this.resourceId + '&criterio=' + me.criterio;
            axios.get(url).then(function (response) {
              //000  me.hayFotos = 0;
              
              var respuesta = response.data;
               console.log('INICIO--------listarfotos',response,'response.data',response.data);

               //console.log(respuesta);
               //0000  me.obrasUsuario();
               //console.log('FIN----------listarfotos');
               me.images = respuesta.fotosObraUrl;
            }).catch(function (error) {
                console.log(error);
                if (error.response.status === 401) {
                    window.location = "/login";
                }

                //console.log(error);
            });
        },
     

    }
  }
</script> 

<style scoped>
  .image {
    float: left;
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;
    border: 1px solid #ebebeb;
    margin: 5px;
  }
</style>