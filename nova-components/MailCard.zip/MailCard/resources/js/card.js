Nova.booting((Vue, router, store) => {
    Vue.component('mail-card', require('./components/Card'))
})
